﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_otomasyonu
{
    class Ebat
    {
        public string Adi {  get; set; }
        public double Carpan { get; set; }
        public override string ToString()
        {
            return Adi;
        }
    }
}
